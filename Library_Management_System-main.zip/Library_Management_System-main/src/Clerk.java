/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library;

/**
 *
 * @author Minahil Imtiaz
 */
public class Clerk extends Staff {

    Clerk(int user_id, String user_name, char gender) {
        super(user_id, user_name, gender);
    }
}
